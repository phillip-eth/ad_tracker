from django.apps import AppConfig


class OfficeManagerConfig(AppConfig):
    name = 'office_manager'
